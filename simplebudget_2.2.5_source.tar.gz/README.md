# <p style="text-align: center;">Simple Budget</p>
# <p style="text-align: center;">README.MD</p>


Simple Budget is written in Free Pascal using the Lazarus IDE.

Lazarus is an IDE to create graphical and console applications with Free Pascal. Free Pascal is Pascal and Object Pascal compiler that runs on Windows, Linux, Mac OS X, FreeBSD and more.

The assumption is made that if one that wants to compile Simple Budget from source they have a working knowledge of Lazarus and Free Pascal.  This is not a tutorial.

To compile Simple Budget with Lazarus, the following required packages must be installed in the Lazarus IDE:


  * lazreportpdfexport
  * pack_powerpdf
  * uniqueinstance_package
  * LazControls
  * lazreport
  * TAChartLazarusPkg
  * DateTimeCtrls
  * LCL

Extract the archive, and open the project file "simplebudget2.lpi" and compile in the Lazarus IDE.

The Simple Budget breakout Calculator is seperate project that must be compiled on its own.  The executable must be in the same directory as the Simple Budget executable.

Simple Budget is a simple off-line personal budgeting system that helps you keep track of your spending using the envelope budgeting system that allows savings from month to month.  Simple Budget was written for me personally and hope it is something you can use as well.  The quality of this code may not be up to your standards.

    Copyright (C) 2020  John McDougall

simplebudget.mcdougallshome.net

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA. 