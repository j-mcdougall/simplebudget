# Simple Budget
# Calculator
Simple Budget Calculator is written in Free Pascal using the Lazarus IDE.

Lazarus is an IDE to create graphical and console applications with Free Pascal. Free Pascal is Pascal and Object Pascal compiler that runs on Windows, Linux, Mac OS X, FreeBSD and more.

The assumption is made that if one that wants to compile Simple Budget Calculator from source they have a working knowledge of Lazarus and Free Pascal.  This is not a tutorial.

To compile Simple Budget Calculator with Lazarus, the following required packages must be installed in the Lazarus IDE:

  * uniqueinstance_package
  * LCL

calculatorunit.pas is from:
[https://github.com/adnan360/simple-calculator-lazarus](URL)

**The project name is "project1.lpi"**

Simple Budget Calculator source code is available at:
[https://github.com/j-mcdougall/simplebudget](URL)

After Simple Budget Calculator is compiled, the executable file "calculator" for linux, or "calculator.exe" for windows, must be placed in the same folder as "simplebudget".

This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA. 